create definer = root@localhost trigger emps_del_trigger
    after delete
    on emps
    for each row
begin 
	insert into emps_back1(employee_id,last_name,salary)
	values(OLD.employee_id,OLD.last_name,OLD.salary);
end;

