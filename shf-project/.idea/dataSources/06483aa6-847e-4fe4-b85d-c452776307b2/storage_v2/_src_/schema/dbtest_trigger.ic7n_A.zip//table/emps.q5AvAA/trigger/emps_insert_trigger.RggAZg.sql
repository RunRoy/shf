create definer = root@localhost trigger emps_insert_trigger
    after insert
    on emps
    for each row
begin	
	#将新添加到emps表中的记录添加到emps_back表中
	insert into emps_back(employee_id,last_name,salary)
	values(NEW.employee_id,NEW.last_name,NEW.salary);
end;

