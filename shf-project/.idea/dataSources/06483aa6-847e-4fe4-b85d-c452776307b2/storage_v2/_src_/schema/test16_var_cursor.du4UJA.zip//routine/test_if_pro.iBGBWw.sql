create
    definer = root@localhost procedure test_if_pro(IN sal double)
begin 
	if sal < 3000
		then delete from employees where salary = sal;
	elseif sal <= 5000
		then update employees set salary = salary + 1000 where salary = sal;
	else 
		update employees set salary = salary +500 where salary = sal;
	end if;	
end;

