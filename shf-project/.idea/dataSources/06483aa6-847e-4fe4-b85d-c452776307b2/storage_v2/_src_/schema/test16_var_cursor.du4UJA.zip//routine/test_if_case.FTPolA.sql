create
    definer = root@localhost function test_if_case(results double) returns char
begin	   
	   declare lv CHAR;
	
	   if  results > 90 then   set lv =  'A';
	   elseif  results > 80  then  SET lv = 'B';
	   elseif results >  60  then  SET lv = 'C';
	   else   SET lv = 'D';
	   end if;
	   RETURN lv;
 end;

