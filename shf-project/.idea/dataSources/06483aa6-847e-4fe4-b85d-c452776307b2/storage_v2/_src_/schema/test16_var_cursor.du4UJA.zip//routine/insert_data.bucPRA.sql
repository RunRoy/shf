create
    definer = root@localhost procedure insert_data(IN insert_count int)
BEGIN	
	#声明变量
	declare init_count int default 1; #初始化条件
	
	while init_count <= insert_count do #循环条件
		#循环体
		insert into admin(user_name,user_pwd) values(concat('atguigu-',init_count),round(rand()*1000000)); 
		#迭代条件
		set init_count  = init_count + 1; 
	end while;
END;

