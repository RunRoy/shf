create
    definer = root@localhost function dept_sal(dept_name varchar(30)) returns double
BEGIN 	
	#声明变量
	declare dep_avg_sal double;
	
	#赋值
	SELECT AVG(salary) into dep_avg_sal
		FROM departments d JOIN employees e
		ON e.department_id = d.department_id
		WHERE d.department_name = dept_name;
	RETURN (dep_avg_sal);
END;

