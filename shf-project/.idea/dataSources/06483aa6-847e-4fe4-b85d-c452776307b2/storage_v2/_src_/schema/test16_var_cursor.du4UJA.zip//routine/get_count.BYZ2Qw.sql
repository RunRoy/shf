create
    definer = root@localhost function get_count() returns int
BEGIN 	
	#声明局部变量
	declare emp_count int;
	
	#赋值
	 SELECT COUNT(*) into emp_count FROM employees;
	
	RETURN emp_count;
END;

