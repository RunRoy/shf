create
    definer = root@localhost function test_case_if(value1 double) returns char
begin 
	declare results char;
	
	case 
	when value1 > 90 then set results = 'A';
	WHEN value1 > 80 THEN SET results = 'B';
	WHEN value1 > 60 THEN SET results = 'C';
	else SET results = 'D';
	
	end case;
	
	return results;
end;

