create
    definer = root@localhost function ename_salary(emp_name varchar(15)) returns double
BEGIN 	
	#声明局部变量
	declare emp_sal double;
	
	#赋值
	SELECT salary  into emp_sal from employees WHERE last_name = emp_name;
	RETURN (emp_sal);
END;

