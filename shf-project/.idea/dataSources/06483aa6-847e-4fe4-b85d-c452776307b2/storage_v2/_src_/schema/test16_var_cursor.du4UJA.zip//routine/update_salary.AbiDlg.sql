create
    definer = root@localhost procedure update_salary(IN dept_id int, IN change_sal_count int)
begin
	#声明变量
	declare emp_id int; #记录员工id
	declare emp_hire_date date; #记录员工入职时间
	
	
	declare init_count int default 1; #用于表示循环结构的初始化条件
	DECLARE add_sal_rate DOUBLE; #记录涨薪的比例
	
	#声明游标
	declare emp_cursor cursor for select employee_id,hire_date from employees 
	where department_id = dept_id order by salary asc;
	
	#打开游标
	OPEN emp_cursor;
	
	while init_count <= change_sal_count do
		
		#使用游标
		FETCH emp_cursor INTO emp_id,emp_hire_date;
		
		#获取涨薪的比例
		if (year(emp_hire_date) < 1995)
			then set add_sal_rate =  1.2;
		elseif(YEAR(emp_hire_date) <= 1998)
			then set add_sal_rate = 1.15;
		ELSEIF(YEAR(emp_hire_date) <= 2001)
			THEN SET add_sal_rate = 1.10;
		else
			SET add_sal_rate = 1.05;
		end if;
		
		#涨薪操作
		update employees set salary = salary * add_sal_rate
		where employee_id = emp_id;
		
		#迭代条件的更新
		set init_count = init_count + 1;
		
		end while;
	#关闭游标
	close emp_cursor;
end;

