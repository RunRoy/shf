create
    definer = root@localhost function add_float(value1 float, value2 float) returns float
BEGIN 	
	#声明局部变量
	declare sum_vlu FLOAT;
	
	#赋值
	set sum_vlu = value1 + value2;
	
	RETURN(sum_vlu);
END;

