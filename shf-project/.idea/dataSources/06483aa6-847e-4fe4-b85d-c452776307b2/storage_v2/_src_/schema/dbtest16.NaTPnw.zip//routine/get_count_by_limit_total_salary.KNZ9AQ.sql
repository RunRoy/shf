create
    definer = root@localhost procedure get_count_by_limit_total_salary(IN limit_total_salary double, OUT total_count int)
begin
	#声明局部变量
	declare sum_sal double default 0.0; #记录累加的工资总额
	declare emp_sal double; #记录每一某一个员工的工资
	declare emp_count int default 0; #记录累加的人数
	
	#1.声明游标
	declare emp_cursor cursor for select salary from employees order by salary desc;
	
	#2.打开游标
	open emp_cursor;
	
	repeat 
	
		#3.使用游标	
		fetch emp_cursor into emp_sal;
		
		set sum_sal = sum_sal + emp_sal;
		set emp_count = emp_count + 1;
		until sum_sal >= limit_total_salary
	end repeat;
	
	set total_count = emp_count;
	
	#4.关闭游标
	close emp_cursor;
	
	
end;

