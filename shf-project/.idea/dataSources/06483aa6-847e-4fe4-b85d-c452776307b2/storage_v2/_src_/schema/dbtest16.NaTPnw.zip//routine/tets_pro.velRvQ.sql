create
    definer = root@localhost procedure tets_pro()
begin	
	#声明
	declare emp_name varchar(25);
	declare sal double(10,2) default 0.0;
	#赋值
	select last_name,salary into  emp_name,sal
	from employees
	where employee_id = 102;
	#使用
	select emp_name,sal;
	
	
end;

