create
    definer = root@localhost procedure test_calse()
begin
	#演示1：case ....when ...then...
	/*
	declare var int default 2;
	
	case var
		when 1 then select 'var = 1';
		when 2 then select 'var = 2';
		WHEN 3 THEN SELECT 'var = 3';
		else select 'other value';
	end case;
	*/
	#演示2 case when ... then ...
	declare var1 int default 10;
	case 
		when var1 >= 100 then select '三位数';
		when var1 >= 10  THEN SELECT '两位数';
		else select '个位数';
	end case;
	
end;

