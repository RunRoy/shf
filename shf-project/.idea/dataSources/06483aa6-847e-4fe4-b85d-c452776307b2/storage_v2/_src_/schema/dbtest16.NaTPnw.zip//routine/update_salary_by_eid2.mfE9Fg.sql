create
    definer = root@localhost procedure update_salary_by_eid2(IN emp_id int)
begin
	#定义局部变量
	declare emp_sal double; #记录员工工资
	declare	emp_hire_date DOUBLE; #记录员工入职公司年数
	
	#赋值
	select salary into emp_sal from employees where employee_id = emp_id;
	
	select datediff(curdate(),hire_date) /365 into emp_hire_date from employees where employee_id = emp_id;
	
	#判断
	if emp_sal < 9000 and emp_hire_date > 5 
		then update employees set salary = salary + 500 where employee_id = emp_id;
	else		
		update employees set salary = salary + 100 where employee_id = emp_id;	
	end if ;	
end;

