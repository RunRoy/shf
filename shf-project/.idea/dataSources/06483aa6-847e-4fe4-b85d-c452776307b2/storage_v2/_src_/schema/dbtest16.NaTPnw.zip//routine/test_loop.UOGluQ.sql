create
    definer = root@localhost procedure test_loop()
begin 
	#声明局部变量
	declare num int default 1;
	
	loop_label:LOOP
		#重新赋值
		set num =  num + 1;
		if num >= 10 then leave loop_label;
		end if; 
	end loop loop_label;
	
	#查看num
	select num;
end;

