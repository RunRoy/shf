create
    definer = root@localhost procedure leave_while(OUT num int)
begin	
	#定义变量
	declare while_count int default 0; #记录循环次数
	declare avg_sal double; #记录平均工资
	
	select avg(salary) into avg_sal from employees; #①初始化条件
	
	while_label:while true  do #② 循环条件
	
		#③循环体
		if avg_sal <= 10000 then
			leave while_label;
		end if;	
		
		UPDATE employees SET salary = salary * 0.9;
		SET while_count = while_count + 1;
		 
		#④迭代条件
		SELECT AVG(salary) INTo avg_sal FROM employees;
	
	end while;
	
	#给num赋值
	set num = while_count;
	
end;

