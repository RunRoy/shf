create
    definer = root@localhost procedure leave_begin(IN num int)
begin_label:begin
	if num <= 0
		then  leave begin_label;
	elseif num = 1
		then select avg(salary) from employees;
	ELSEIF num = 2
		then select min(salary) from employees;
	else 
		select max(salary) from employees;
	end if;
	
	select count(*) from employees;
end;

