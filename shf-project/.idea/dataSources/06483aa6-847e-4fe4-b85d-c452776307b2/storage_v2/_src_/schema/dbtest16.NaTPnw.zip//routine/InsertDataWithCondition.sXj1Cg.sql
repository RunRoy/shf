create
    definer = root@localhost procedure InsertDataWithCondition()
BEGIN
		#处理程序
		#方式1：
		#declare exit handler for 1062 set @por_value = -1
		#方式2：
		#declare exit handler for sqlstate '23000' set @por_value = -1
		#方式3：
		#定义条件
		declare duplicate_entry condition for 1062;
		declare exit handler for duplicate_entry set @por_value = -1;
		
		SET @x = 1;
		INSERT INTO departments(department_name) VALUES('测试');
		SET @x = 2;
		INSERT INTO departments(department_name) VALUES('测试');
		SET @x = 3;
	END;

