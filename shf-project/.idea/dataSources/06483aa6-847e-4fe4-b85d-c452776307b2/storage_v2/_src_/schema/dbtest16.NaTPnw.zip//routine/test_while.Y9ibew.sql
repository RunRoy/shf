create
    definer = root@localhost procedure test_while()
begin
	#初始化条件
	declare num int default 1;
	#循环条件
	while num <= 10 do
		#循环体 （略）
		
		#迭代条件
		set num = num + 1;
	end while;
	
	#查询
	select num;
end;

