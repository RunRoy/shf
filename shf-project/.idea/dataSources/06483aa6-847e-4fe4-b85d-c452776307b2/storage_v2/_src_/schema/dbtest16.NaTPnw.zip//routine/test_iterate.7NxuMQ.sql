create
    definer = root@localhost procedure test_iterate()
begin
	declare num int default 0;
		
	loop_labe:loop
		#赋值
		set num = num + 1;
		
		if  num < 10 
			then iterate loop_labe;
		elseif   num > 15 
			then leave loop_labe;
		end if;
		
		select '尚硅谷：让天下没有难学的技术';
	
	end loop;
	
	
end;

