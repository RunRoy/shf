create
    definer = root@localhost procedure update_salary_by_eid4(IN emp_id int)
begin
	#局部变量的声明
	declare emp_sal double; #记录员工工资
	declare bonus double; #记录奖金率
	
	#局部变量赋值
	select salary into emp_sal from employees where employee_id = emp_id;
	SELECT commission_pct INTO bonus FROM employees WHERE employee_id = emp_id;
	
	#判断
	case 
	when emp_sal < 9000 
		then update employees set salary = 9000 WHERE employee_id = emp_id;
	when emp_sal >= 9000 and emp_sal < 10000 and bonus is null
	        then update employees set commission_pct = 0.01 WHERE employee_id = emp_id;
	else update employees SET salary = salary + 100 WHERE employee_id = emp_id;
	end case;
	
end;

