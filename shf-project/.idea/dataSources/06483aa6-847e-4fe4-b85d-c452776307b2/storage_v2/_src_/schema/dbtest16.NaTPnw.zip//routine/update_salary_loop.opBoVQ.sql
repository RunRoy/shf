create
    definer = root@localhost procedure update_salary_loop(OUT num int)
begin 
	#声明变量
	declare avg_sal double; #记录员工的平均工资
	
	declare loop_count int default 0;#记录循环的次数
	
	#获取员工的平均工资
	select avg(salary) into avg_sal from employees; 
	
	loop_lab:loop
		#结束循环条件
		if avg_sal  >= 12000 
			THEN LEAVE loop_lab;
		end if;
			
		#如果低于12000，就更新员工工资
		update employees set salary = salary * 1.1;
		
		#更新avg_sal变量的值
		SELECT AVG(salary) INTO avg_sal FROM employees;
		
		#记录循环的次数 
		set loop_count = loop_count + 1;
	end loop loop_lab;
	
	#给num赋值
	set num =  loop_count;
			
end;

