create
    definer = root@localhost procedure test_repeat()
begin
	#声明变量
	declare num int default 1;
	
	repeat
		set num = num + 1;
		until num >= 10
	end repeat;
	
	#查看
	select num; 
end;

