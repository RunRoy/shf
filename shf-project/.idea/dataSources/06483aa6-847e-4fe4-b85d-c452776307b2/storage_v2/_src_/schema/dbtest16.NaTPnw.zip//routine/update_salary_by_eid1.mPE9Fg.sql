create
    definer = root@localhost procedure update_salary_by_eid1(IN emp_id int)
begin		
		#声明局部变量
		declare emp_salary double;
		declare hire_year double;
		
		#赋值
		select salary into emp_salary from employees where employee_id = emp_id;
		
		select datediff(curdate(), hire_date) /365 into hire_year  from employees where employee_id = emp_id;
		
		#判断
		if emp_salary < 8000 and hire_year >= 5 
			then update employees set salary = salary + 500 where employee_id = emp_id;
		end if;
end;

