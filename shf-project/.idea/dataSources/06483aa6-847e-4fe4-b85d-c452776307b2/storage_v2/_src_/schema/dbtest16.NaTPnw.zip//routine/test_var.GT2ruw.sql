create
    definer = root@localhost procedure test_var()
begin
	#声明局部变量
	declare a int default 0;
	declare b int ;
	#DECLARE a,b INT DEFAULT 0;
	declare emp_name varchar(25);
	
	#赋值
	set a = 1;
	SEt b := 2;
	
	select last_name into emp_name from employees where employee_id = 101;
	
	#使用
	select a,b,emp_name;
end;

