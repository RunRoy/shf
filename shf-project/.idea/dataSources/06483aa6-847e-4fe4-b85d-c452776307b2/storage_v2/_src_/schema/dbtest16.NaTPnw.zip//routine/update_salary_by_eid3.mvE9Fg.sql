create
    definer = root@localhost procedure update_salary_by_eid3(IN emp_id int)
BEGIN		
	#声明局部变量
	declare emp_sal double; #记录员工工资
	declare bonus double; #记录员工奖金率
	
	#赋值
	select salary into emp_sal from employees where employee_id = emp_id;
	select commission_pct into bonus from employees WHERE employee_id = emp_id;
	
	#判断
	if emp_sal < 9000 
		then update employees set salary = 9000 WHERE employee_id = emp_id;
	elseif emp_sal < 10000 and bonus is null
		then update employees set commission_pct = 0.01 WHERE employee_id = emp_id;
	else 
		UPDATE employees SET salary = salary + 100 WHERE employee_id = emp_id;
	end if;	
		
END;

