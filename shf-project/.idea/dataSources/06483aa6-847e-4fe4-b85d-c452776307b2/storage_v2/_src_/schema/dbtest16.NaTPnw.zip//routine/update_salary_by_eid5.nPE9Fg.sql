create
    definer = root@localhost procedure update_salary_by_eid5(IN emp_id int)
begin
	#局部变量的声明
	declare emp_hire_date int; #记录员工入职公司的总时间(单位：年)
	
	#赋值 
	select round(datediff(curdate(),hire_date) / 365) into emp_hire_date
        from employees WHERE employee_id = emp_id;
	
	#判断
	case emp_hire_date
		when 0  THEN UPDATE employees SET salary = salary + 50 where employee_id = emp_id;	
		when 1  THEN UPDATE employees SET salary = salary + 100 WHERE employee_id = emp_id;
		WHEN 2	THEN UPDATE employees SET salary = salary + 200 WHERE employee_id = emp_id;
		WHEN 3	THEN UPDATE employees SET salary = salary + 300 WHERE employee_id = emp_id;
		WHEN 4	THEN UPDATE employees SET salary = salary + 400 WHERE employee_id = emp_id;
		else    UPDATE employees set salary = salary + 500 WHERE employee_id = emp_id;
	end case;
end;

