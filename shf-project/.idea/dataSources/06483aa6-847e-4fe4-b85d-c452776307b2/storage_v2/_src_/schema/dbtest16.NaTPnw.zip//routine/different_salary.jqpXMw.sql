create
    definer = root@localhost procedure different_salary(IN emp_id int, OUT dif_salary double)
begin
	#分析： 查询emp_id员工的工资：查询出emp_id员工的管理者id;查询管理者id的工资；计算工资的差值	
	
	#声明变量
	declare emp_sal double default 0.0; #记录员工的工资
	declare mgr_sal DOUBLE DEFAULT 0.0; #记录管理者的工资
	
	declare mgr_id int default 0; #记录管理者的id
	
	#赋值
	select salary into emp_sal from employees where employee_id = emp_id;
	
	SELECT manager_id into mgr_id from employees where employee_id = emp_id;
	SELECT salary into mgr_sal FROM employees WHERE employee_id = mgr_id;
	
	set dif_salary = mgr_sal - emp_sal;
end;

