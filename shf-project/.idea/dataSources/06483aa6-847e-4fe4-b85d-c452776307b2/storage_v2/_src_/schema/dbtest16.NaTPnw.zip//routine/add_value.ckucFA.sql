create
    definer = root@localhost procedure add_value()
begin 	
	#声明
	declare value1,value2,sum_value1 int ;
	 
	#赋值
	set value1 := 60;
	set value2 := 40;
	
	set sum_value1 = value1 + value2;
	# 使用
	select sum_value1;
end;

