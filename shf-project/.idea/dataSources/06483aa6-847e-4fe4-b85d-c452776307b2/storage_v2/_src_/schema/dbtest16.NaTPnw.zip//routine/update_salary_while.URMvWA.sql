create
    definer = root@localhost procedure update_salary_while(OUT num int)
begin
	#声明变量
	DECLARE avg_sal DOUBLE; #记录员工的平均工资
	DECLARE while_count INT DEFAULT 0;#记录循环的次数
	
	
	#赋值
	SELECT AVG(salary) INTO avg_sal FROM employees; 
		
	while avg_sal > 5000 do
		update employees set salary = salary * 0.9 ;
		set while_count = while_count + 1;	
		
		SELECT AVG(salary) INTO avg_sal FROM employees; 
	end while ;
	#给num赋值
	SET num = while_count;
	
end;

