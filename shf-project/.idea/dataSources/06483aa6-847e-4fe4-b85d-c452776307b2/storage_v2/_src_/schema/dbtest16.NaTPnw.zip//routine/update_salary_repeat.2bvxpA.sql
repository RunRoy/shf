create
    definer = root@localhost procedure update_salary_repeat(OUT num int)
begin
	#声明变量
	declare repeat_count int DEFAULT 0;
	declare avg_sal double;
	
	#赋值
	select avg(salary) into avg_sal from employees;
	
	repeat
		update employees set salary = salary * 1.15;
		SET repeat_count = repeat_count + 1;		
		
		SELECT AVG(salary) INTO avg_sal FROM employees;
		until avg_sal >= 13000
	
	 end repeat;
	 
	 #给num赋值
	 set num = repeat_count;
	
end;

