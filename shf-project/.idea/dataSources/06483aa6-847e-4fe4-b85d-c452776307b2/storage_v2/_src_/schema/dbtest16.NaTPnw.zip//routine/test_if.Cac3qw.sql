create
    definer = root@localhost procedure test_if()
begin
        #情况1：
	#声明局部变量
	#declare stu_name varchar(15);
	
	#if stu_name is null
	#	then select 'stu_name is null';
	#end if;
	
	#情况2：二选一
	#declare email varchar(25) default 'aaa';
	
	#if email is null 
	#	then select 'email is null';
	#else 
	#	select 'email is not null';
	#end if;
	
	#情况3：
        declare age int default 20;
        
        if age > 40
		then select '中老年';
	elseif age > 18
		then select '青壮年';
	elseif age > 8
		then select '青少年';
	else 
	         select '婴幼儿';
	end if ;	
end;

