create definer = root@localhost trigger salary_check_trigger
    before insert
    on employees
    for each row
begin
	#查询到要添加的数据的manager的薪资
	declare mgr_sal double;
	
	select salary INTO mgr_sal from employees 
	where employee_id = new.manager_id;
	
	if new.salary > mgr_sal
		then SIGNAL SQLSTATE 'HY000' SET MESSAGE_TEXT = '薪资高于领导薪资错误';
	end if;
end;

