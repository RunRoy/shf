create definer = root@localhost trigger before_insert_test_tri
    before insert
    on test_trigger
    for each row
begin
	insert into test_trigger_log(t_log)
	values('before insert...');
end;

