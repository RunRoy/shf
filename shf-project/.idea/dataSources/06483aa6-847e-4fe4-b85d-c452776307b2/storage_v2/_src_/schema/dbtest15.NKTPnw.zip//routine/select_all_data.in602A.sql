create
    definer = root@localhost procedure select_all_data()
begin
	select * from employees;
end;

