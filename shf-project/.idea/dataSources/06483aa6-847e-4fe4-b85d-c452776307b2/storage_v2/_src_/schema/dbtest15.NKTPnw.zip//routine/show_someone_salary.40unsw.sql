create
    definer = root@localhost procedure show_someone_salary(IN empname varchar(25))
begin 
      select salary from employees
      where last_name  = empname ;
end;

