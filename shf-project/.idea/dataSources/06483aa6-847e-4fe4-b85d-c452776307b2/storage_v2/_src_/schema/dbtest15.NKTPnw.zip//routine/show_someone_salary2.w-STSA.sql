create
    definer = root@localhost procedure show_someone_salary2(IN empname varchar(25), OUT empsalary decimal(10, 2))
begin
	select salary into empsalary 
	from employees 
	where last_name = empname;
end;

