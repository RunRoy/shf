create
    definer = root@localhost procedure show_max_salary() comment '查询最高工资' sql security invoker
begin
	select max(salary) from employees; 
end;

