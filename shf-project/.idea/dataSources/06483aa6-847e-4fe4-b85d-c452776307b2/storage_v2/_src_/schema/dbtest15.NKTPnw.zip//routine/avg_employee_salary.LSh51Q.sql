create
    definer = root@localhost procedure avg_employee_salary()
begin
	select avg(salary) from employees;
end;

