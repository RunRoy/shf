create
    definer = root@localhost function email_by_name() returns varchar(25) deterministic reads sql data
begin
	return (select email from employees where last_name = 'Abel');
	
end;

