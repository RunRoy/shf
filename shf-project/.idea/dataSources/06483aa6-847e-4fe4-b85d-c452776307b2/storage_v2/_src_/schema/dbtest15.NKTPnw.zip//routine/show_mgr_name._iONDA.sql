create
    definer = root@localhost procedure show_mgr_name(INOUT empname varchar(25))
begin 
	select last_name into empname
	from employees
	where employee_id = (
				SELECT manager_id
				FROM employees
				WHERE last_name = empname
	);		
end;

