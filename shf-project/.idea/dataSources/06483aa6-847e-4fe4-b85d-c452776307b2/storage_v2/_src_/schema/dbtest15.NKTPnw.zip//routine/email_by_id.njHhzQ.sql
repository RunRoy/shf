create
    definer = root@localhost function email_by_id(emp_id int) returns varchar(25)
begin
	return (select email from employees where employee_id = emp_id);
end;

