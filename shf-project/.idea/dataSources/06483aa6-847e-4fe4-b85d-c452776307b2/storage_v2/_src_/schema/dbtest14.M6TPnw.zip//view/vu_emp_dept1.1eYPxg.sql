create definer = root@localhost view vu_emp_dept1 as
select concat(`e`.`last_name`, '(', `d`.`department_name`, ')') AS `emp_info`
from (`dbtest14`.`emps` `e` join `dbtest14`.`depts` `d` on ((`e`.`department_id` = `d`.`department_id`)));

