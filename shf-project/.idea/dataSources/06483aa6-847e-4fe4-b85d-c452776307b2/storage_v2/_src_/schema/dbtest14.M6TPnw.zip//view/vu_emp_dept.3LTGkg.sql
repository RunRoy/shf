create definer = root@localhost view vu_emp_dept as
select `e`.`employee_id`     AS `employee_id`,
       `e`.`department_id`   AS `department_id`,
       `d`.`department_name` AS `department_name`
from (`dbtest14`.`emps` `e` join `dbtest14`.`depts` `d` on ((`e`.`department_id` = `d`.`department_id`)));

