create definer = root@localhost view employee_vu as
select `dbtest14`.`emps`.`employee_id`    AS `employee_id`,
       `dbtest14`.`emps`.`first_name`     AS `first_name`,
       `dbtest14`.`emps`.`last_name`      AS `last_name`,
       `dbtest14`.`emps`.`email`          AS `email`,
       `dbtest14`.`emps`.`phone_number`   AS `phone_number`,
       `dbtest14`.`emps`.`hire_date`      AS `hire_date`,
       `dbtest14`.`emps`.`job_id`         AS `job_id`,
       `dbtest14`.`emps`.`salary`         AS `salary`,
       `dbtest14`.`emps`.`commission_pct` AS `commission_pct`,
       `dbtest14`.`emps`.`manager_id`     AS `manager_id`,
       `dbtest14`.`emps`.`department_id`  AS `department_id`
from `dbtest14`.`emps`
where (`dbtest14`.`emps`.`department_id` = 80);

