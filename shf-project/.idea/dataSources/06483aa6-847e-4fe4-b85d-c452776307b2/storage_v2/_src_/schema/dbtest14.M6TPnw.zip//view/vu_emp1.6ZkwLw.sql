create definer = root@localhost view vu_emp1 as
select `dbtest14`.`emps`.`employee_id` AS `employee_id`,
       `dbtest14`.`emps`.`last_name`   AS `last_name`,
       `dbtest14`.`emps`.`salary`      AS `salary`,
       `dbtest14`.`emps`.`email`       AS `email`,
       `dbtest14`.`emps`.`hire_date`   AS `hire_date`
from `dbtest14`.`emps`;

