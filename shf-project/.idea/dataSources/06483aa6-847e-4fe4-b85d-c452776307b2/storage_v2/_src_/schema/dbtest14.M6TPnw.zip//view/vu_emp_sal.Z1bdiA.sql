create definer = root@localhost view vu_emp_sal as
select `dbtest14`.`emps`.`department_id` AS `department_id`, avg(`dbtest14`.`emps`.`salary`) AS `avg_sal`
from `dbtest14`.`emps`
where (`dbtest14`.`emps`.`department_id` is not null)
group by `dbtest14`.`emps`.`department_id`;

