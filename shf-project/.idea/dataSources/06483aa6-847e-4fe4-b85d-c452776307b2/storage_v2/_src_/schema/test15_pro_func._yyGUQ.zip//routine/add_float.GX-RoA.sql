create
    definer = root@localhost function add_float(value1 float, value2 float) returns float
BEGIN 
	return(select value1 + value2);
END;

