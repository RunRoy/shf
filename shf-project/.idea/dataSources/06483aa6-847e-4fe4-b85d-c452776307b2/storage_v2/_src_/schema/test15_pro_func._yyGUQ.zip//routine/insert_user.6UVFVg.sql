create
    definer = root@localhost procedure insert_user(IN user_name varchar(15), IN pwd varchar(25))
begin
	insert into admin(user_name,pwd)
	values (user_name,pwd);
end;

