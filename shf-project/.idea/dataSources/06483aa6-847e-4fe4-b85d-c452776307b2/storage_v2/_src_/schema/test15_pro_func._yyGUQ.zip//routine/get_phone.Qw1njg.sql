create
    definer = root@localhost procedure get_phone(IN id int, OUT name varchar(15), OUT phone varchar(15))
begin
	select b.name,b.phone into name,phone
	from beauty b
	where b.id = id;
end;

