create
    definer = root@localhost function get_count() returns int
begin 
	return(select count(*) from employees);
end;

