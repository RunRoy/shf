create
    definer = root@localhost function ename_salary(emp_name varchar(15)) returns double
BEGIN 
	return (select salary FROM employees where last_name = emp_name);
END;

