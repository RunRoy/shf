create
    definer = root@localhost procedure date_diff(IN birth1 date, IN birth2 date, OUT sum_date int)
begin
	select datediff(birth1,birth2) into sum_date;
end;

