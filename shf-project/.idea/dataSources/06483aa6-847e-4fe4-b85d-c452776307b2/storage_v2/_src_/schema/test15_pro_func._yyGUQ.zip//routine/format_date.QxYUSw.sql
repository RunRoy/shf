create
    definer = root@localhost procedure format_date(IN my_date date, OUT str_date1 varchar(25))
begin
	select date_format(my_date,'%y年%m月%d日') into str_date1;
end;

