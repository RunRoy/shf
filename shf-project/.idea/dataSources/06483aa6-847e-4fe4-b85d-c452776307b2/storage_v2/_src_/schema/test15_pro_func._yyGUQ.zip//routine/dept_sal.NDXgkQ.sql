create
    definer = root@localhost function dept_sal(dept_name varchar(30)) returns double
BEGIN 
	return (select avg(salary)
		from departments d join employees e
		on e.department_id = d.department_id
		where d.department_name = dept_name);
END;

